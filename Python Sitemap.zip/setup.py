from setuptools import setup

APP = ['sitemap_ui.py']
DATA_FILES = []
OPTIONS = {
    'argv_emulation': True,
    'packages': ['requests', 'bs4', 'xml', 'urllib', 'datetime', 're', 'argparse', 'logging', 'random'],
    'iconfile': 'sitemap_icon.icns',  # Eğer bir ikonunuz varsa
    'plist': {
        'CFBundleName': 'Sitemap Oluşturucu',
        'CFBundleDisplayName': 'Sitemap Oluşturucu',
        'CFBundleGetInfoString': "Sitemap Oluşturucu Aracı",
        'CFBundleVersion': "1.0.0",
        'CFBundleShortVersionString': "1.0.0",
        'NSHumanReadableCopyright': u"© 2023, Tüm hakları saklıdır."
    }
}

setup(
    app=APP,
    data_files=DATA_FILES,
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
)
