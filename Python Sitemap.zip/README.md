# Sitemap Oluşturucu

Bu Python aracı, belirtilen bir web sitesini tarayarak sitemap.xml dosyası oluşturur. Python 3.13 veya üzeri sürümleri destekler.

## Özellikler

- Belirtilen URL'den başlayarak web sitesini otomatik tarama
- robots.txt kurallarına uyma (istenirse devre dışı bırakılabilir)
- Tarama gecikmesi ayarlama imkanı
- Belirli URL kalıplarını hariç tutma seçeneği
- Maksimum URL sayısı belirleme
- Sitemap.org standartlarına uygun XML çıktısı oluşturma
- Gerçek zamanlı ilerleme bilgisi
- **Kullanımı kolay grafik arayüz (UI)**

## Kurulum

1. Gerekli bağımlılıkları yükleyin:

```bash
python3 -m pip install -r requirements.txt
```

## Kullanım

### Grafik Arayüz (UI) ile Kullanım

```bash
python3 sitemap_ui.py
```

Bu komut, kullanıcı dostu grafik arayüzünü başlatır. Arayüzde şunları yapabilirsiniz:

- URL giriş alanı ile taranacak siteyi belirtin
- Çıktı dosyasını seçin
- Maksimum taranacak URL sayısını ayarlayın
- Tarama gecikmesini ayarlayın
- robots.txt kurallarına uyulup uyulmayacağını seçin
- Hariç tutulacak URL kalıplarını virgülle ayırarak girin
- Taramayı başlatın ve gerçek zamanlı ilerlemeyi izleyin
- İsterseniz taramayı durdurun
- Tarama tamamlandığında oluşturulan sitemap.xml'i önizleyin
- Tüm log çıktılarını görüntüleyin

### Komut Satırı ile Kullanım

```bash
python3 sitemap_generator.py example.com
```

Bu komut, example.com sitesini tarayarak varsayılan olarak `sitemap.xml` dosyasını oluşturacaktır.

### Gelişmiş Seçenekler (Komut Satırı)

```bash
# Çıktı dosya adını belirlemek için
python3 sitemap_generator.py example.com -o mysitemap.xml

# Maksimum URL sayısını ayarlamak için (varsayılan: 500)
python3 sitemap_generator.py example.com -m 1000

# Tarama gecikmesini ayarlamak için (varsayılan: 0.5 saniye)
python3 sitemap_generator.py example.com -d 1.0

# robots.txt'yi görmezden gelmek için
python3 sitemap_generator.py example.com --no-robots

# Belirli URL kalıplarını hariç tutmak için (regex destekler)
python3 sitemap_generator.py example.com -e "/kategori/" "/etiket/" ".*\?page=.*"

# Detaylı log bilgisi için
python3 sitemap_generator.py example.com -v
```

### Tüm Parametreler (Komut Satırı)

```
positional arguments:
  url                   Taramaya başlanacak URL

optional arguments:
  -h, --help            Yardım mesajını göster
  -o OUTPUT, --output OUTPUT
                        Çıktı dosyasının adı (varsayılan: sitemap.xml)
  -m MAX, --max MAX     Taranacak maksimum URL sayısı (varsayılan: 500)
  -d DELAY, --delay DELAY
                        Tarama gecikmesi - saniye (varsayılan: 0.5)
  --no-robots           robots.txt'yi görmezden gel
  -e EXCLUDE [EXCLUDE ...], --exclude EXCLUDE [EXCLUDE ...]
                        Hariç tutulacak URL kalıpları
  -v, --verbose         Detaylı log bilgisi göster
```

## Örnek Çıktı

Oluşturulan sitemap.xml dosyası şu formatta olacaktır:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com</loc>
    <lastmod>2023-10-25</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>https://example.com/hakkimizda</loc>
    <lastmod>2023-10-25</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <!-- daha fazla URL... -->
</urlset>
```

## Teknik Bilgiler

Bu uygulama şu şekilde çalışır:

1. Belirtilen URL'den başlayarak siteyi tarar
2. HTML sayfalarında bulunan bağlantıları çıkarır
3. Aynı alan adı içindeki ve geçerli sayfa tipindeki bağlantıları filtreler
4. Tüm bulunan sayfaları standart sitemap.xml formatında kaydeder

## Notlar

- Tarama işlemi, hedef sitenin boyutuna bağlı olarak zaman alabilir
- Çok büyük siteleri taramak için `-m` parametresiyle maksimum URL sayısını artırabilirsiniz
- Bazı siteler otomatik tarayıcıları engeller, bu durumda `-d` parametresiyle tarama gecikmesini artırabilirsiniz
- Hariç tutmak istediğiniz URL kalıplarını belirlemek için regex kullanabilirsiniz

## Sorun Giderme

- Eğer "module not found" hatası alırsanız, gerekli kütüphaneleri yüklediğinizden emin olun
- Tarama işlemi sırasında bağlantı hataları alıyorsanız, tarama gecikmesini artırmayı deneyin
- Bazı sayfalar taranmıyorsa, robots.txt kurallarını görmezden gelmek için `--no-robots` seçeneğini kullanın
- UI modunu başlatırken `ImportError: No module named 'ttkthemes'` hatası alırsanız, `pip install ttkthemes` komutunu çalıştırın 