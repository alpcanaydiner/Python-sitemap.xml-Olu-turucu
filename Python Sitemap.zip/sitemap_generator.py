#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import requests
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET
from xml.dom import minidom
import urllib.parse
import datetime
import time
import re
from urllib.robotparser import RobotFileParser
import os
import logging
import sys
import random

# Loglama yapılandırması
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

class SitemapGenerator:
    def __init__(self, start_url, output_file="sitemap.xml", max_urls=500, 
                 crawl_delay=0.5, respect_robots=True, excluded_patterns=None):
        """
        Sitemap oluşturucu sınıfı.
        
        Args:
            start_url (str): Taramaya başlanacak URL
            output_file (str): Çıktı dosyasının adı
            max_urls (int): Taranacak maksimum URL sayısı
            crawl_delay (float): Her istek arasındaki bekleme süresi (saniye)
            respect_robots (bool): robots.txt dosyasına uyulup uyulmayacağı
            excluded_patterns (list): Hariç tutulacak URL kalıpları listesi
        """
        # URL'yi standart formata getir
        self.start_url = start_url
        if not self.start_url.startswith(('http://', 'https://')):
            self.start_url = 'https://' + self.start_url
        
        # URL'nin sonunda / olduğundan emin ol
        if not self.start_url.endswith('/'):
            self.start_url += '/'
            
        self.base_url = self._get_base_url(self.start_url)
        self.output_file = output_file
        self.max_urls = max_urls
        self.crawl_delay = crawl_delay
        self.respect_robots = respect_robots
        self.excluded_patterns = excluded_patterns or []
        
        # Debug bilgisi
        print(f"Base URL: {self.base_url}")
        print(f"Start URL: {self.start_url}")
        
        # User-Agent bilgisi - daha gerçekçi ve rastgele bir user agent kullanalım
        self.user_agents = [
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0'
        ]
        
        self.headers = {
            'User-Agent': random.choice(self.user_agents),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'tr,en-US;q=0.7,en;q=0.3',
            'Referer': self.base_url,
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0'
        }
        
        # Taranmış URL'leri izlemek için
        self.visited_urls = set()
        self.urls_to_crawl = [self.start_url]
        self.sitemap_urls = []
        
        # URL varyantlarını izlemek için
        self.url_variants = {self.start_url}  # Ana URL'nin varyantlarını izler
        
        # Debug bilgisi için gecikmişleri sakla 
        self.skipped_urls = []
        self.external_urls = []
        
        # Robots.txt tarayıcısı
        self.robots_parser = None
        if self.respect_robots:
            self._setup_robots_parser()
    
    def _get_base_url(self, url):
        """URL'den base URL'yi çıkarır."""
        parsed_url = urllib.parse.urlparse(url)
        return f"{parsed_url.scheme}://{parsed_url.netloc}"
    
    def _setup_robots_parser(self):
        """Robots.txt dosyasını analiz eder."""
        robots_url = urllib.parse.urljoin(self.base_url, '/robots.txt')
        self.robots_parser = RobotFileParser(robots_url)
        try:
            self.robots_parser.read()
            logger.info(f"Robots.txt okundu: {robots_url}")
        except Exception as e:
            logger.warning(f"Robots.txt okunurken hata: {e}")
            print(f"Robots.txt sorunu: {e}")
            self.robots_parser = None
    
    def _can_fetch(self, url):
        """robots.txt'ye göre URL'nin taranıp taranamayacağını kontrol eder."""
        if not self.respect_robots or self.robots_parser is None:
            return True
        
        can_fetch = self.robots_parser.can_fetch("*", url)
        if not can_fetch:
            print(f"Robots.txt tarafından engellendi: {url}")
        return can_fetch
    
    def _is_valid_url(self, url):
        """URL'nin geçerli ve taranabilir olup olmadığını kontrol eder."""
        try:
            # Uzunluğu aşırı olan URL'leri atla (muhtemelen sonsuz parametre üretimi)
            if len(url) > 500:
                self.skipped_urls.append(f"URL çok uzun: {url[:100]}...")
                return False
                
            # Protokolü olmayan URL'leri temizle
            if url.startswith('//'):
                url = 'https:' + url
                
            # Göreceli URL'leri düzenle
            if not url.startswith(('http://', 'https://')):
                return False
                
            parsed = urllib.parse.urlparse(url)
            
            # Dış bağlantıları atla
            if parsed.netloc and parsed.netloc not in self.base_url:
                self.external_urls.append(url)
                return False
            
            # Hariç tutulan kalıpları kontrol et
            for pattern in self.excluded_patterns:
                if re.search(pattern, url):
                    self.skipped_urls.append(f"Hariç tutulan kalıp ({pattern}): {url}")
                    return False
            
            # Hash içeren URL'leri temizle
            if '#' in url:
                url = url.split('#')[0]
            
            # Sorgu parametreli URL'leri daha esnek kontrol edelim
            if '?' in url:
                # Çoğu dinamik sayfayı kabul edelim, ancak bazı özel parametreleri engelleyebiliriz
                forbidden_params = ['utm_', 'fbclid', 'gclid', 'sort=', 'order=', 'sid=', 'session=']
                if any(param in url.lower() for param in forbidden_params):
                    self.skipped_urls.append(f"Engellenen parametre: {url}")
                    return False
            
            # Robots.txt'ye uygun olup olmadığını kontrol et
            if not self._can_fetch(url):
                self.skipped_urls.append(f"Robots.txt tarafından engellenen: {url}")
                return False
            
            # Dosya uzantılarını kontrol et (örn., görüntüler, PDF'ler, vb.)
            path = parsed.path.lower()
            invalid_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.pdf', '.doc', '.docx', 
                                 '.xls', '.xlsx', '.zip', '.rar', '.css', '.js', '.svg', 
                                 '.ico', '.mp3', '.mp4', '.avi', '.mov', '.webm', '.woff', 
                                 '.woff2', '.ttf', '.eot', '.xml', '.json']
            
            if path and '.' in path:
                extension = '.' + path.split('.')[-1]
                if extension in invalid_extensions:
                    self.skipped_urls.append(f"Geçersiz dosya uzantısı: {url}")
                    return False
                
            return True
        except Exception as e:
            logger.error(f"URL kontrol edilirken hata: {e}")
            print(f"URL kontrol hatası ({url}): {e}")
            return False
    
    def _get_url_variants(self, url):
        """Bir URL'nin olası varyantlarını üretir."""
        variants = set()
        parsed = urllib.parse.urlparse(url)
        
        # Ana varyant (temiz URL)
        clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        variants.add(clean_url)
        
        # Sondaki / ile ve olmadan varyantlar
        if clean_url.endswith('/'):
            variants.add(clean_url[:-1])
        else:
            variants.add(clean_url + '/')
            
        return variants
    
    def _normalize_url(self, url):
        """URL'yi normalize eder."""
        try:
            # Başlangıçta fazla slashları temizle
            if url.startswith('https:///'):
                url = url.replace('https:///', 'https://')
            elif url.startswith('http:///'):
                url = url.replace('http:///', 'http://')
            
            # Diğer fazla slashları temizle (protokol sonrası)
            parsed = urllib.parse.urlparse(url)
            if parsed.netloc.startswith('/'):
                fixed_netloc = parsed.netloc.lstrip('/')
                url = urllib.parse.urlunparse((
                    parsed.scheme, 
                    fixed_netloc, 
                    parsed.path, 
                    parsed.params, 
                    parsed.query, 
                    parsed.fragment
                ))
            
            # Çift eğik çizgileri temizle (protokol dışında)
            while '//' in url.replace('://', ':/x'):
                url = url.replace('//', '/')
            url = url.replace(':/x', '://')
            
            # Fragment'i (hash) kaldır
            if '#' in url:
                url = url.split('#')[0]
            
            # URL'yi standartlaştır
            parsed = urllib.parse.urlparse(url)
            
            # URL parçalarını yeniden oluştur
            scheme = parsed.scheme or "https"
            netloc = parsed.netloc
            path = parsed.path
            
            # Path'i normalleştir
            path = re.sub(r"/+", "/", path)
            
            # Query parametrelerini alfabetik sırala (tutarlılık için)
            query = ""
            if parsed.query:
                query_params = sorted(parsed.query.split("&"))
                query = "&".join(query_params)
                
            # URL'yi yeniden oluştur
            normalized = urllib.parse.urlunparse((scheme, netloc, path, "", query, ""))
            return normalized
            
        except Exception as e:
            print(f"URL normalleştirme hatası ({url}): {e}")
            return url
    
    def _extract_links(self, html_content, current_url):
        """HTML içeriğinden linkleri çıkarır."""
        soup = BeautifulSoup(html_content, 'html.parser')
        links = set()  # Tekrarları önlemek için küme kullan
        
        # Debug için ilk 500 karakteri yazdır
        print(f"HTML içeriği (ilk 500 karakter): {html_content[:500]}")
        
        # 1. Tüm a etiketlerini bul
        for a_tag in soup.find_all('a', href=True):
            href = a_tag['href'].strip()
            
            # Boş veya javascript bağlantılarını atla
            if not href or href.startswith(('javascript:', 'mailto:', 'tel:')):
                continue
                
            # Göreceli bağlantıları mutlak bağlantılara dönüştür
            if not href.startswith(('http://', 'https://')):
                # URL birleştirme işleminde // kullanımını önle
                if href.startswith('//'):
                    href = 'https:' + href
                elif href.startswith('/'):
                    # Üçlü slash oluşumunu önle
                    base_url = self.base_url.rstrip('/')
                    href = base_url + href
                else:
                    href = urllib.parse.urljoin(current_url, href)
            
            # URL'yi normalize et
            normalized_url = self._normalize_url(href)
            
            # Geçerli URL'leri listeye ekle
            if self._is_valid_url(normalized_url):
                links.add(normalized_url)
        
        # 2. Form action URL'lerini kontrol et
        for form in soup.find_all('form', action=True):
            action = form.get('action').strip()
            if action and not action.startswith(('javascript:', '#', 'mailto:')):
                # Göreceli bağlantıları mutlak bağlantılara dönüştür
                if not action.startswith(('http://', 'https://')):
                    if action.startswith('//'):
                        action = 'https:' + action
                    elif action.startswith('/'):
                        # Üçlü slash oluşumunu önle
                        base_url = self.base_url.rstrip('/')
                        action = base_url + action
                    else:
                        action = urllib.parse.urljoin(current_url, action)
                
                # URL'yi normalize et
                normalized_url = self._normalize_url(action)
                
                # Geçerli URL'leri listeye ekle
                if self._is_valid_url(normalized_url):
                    links.add(normalized_url)
        
        # 3. iframe src değerlerini kontrol et
        for iframe in soup.find_all('iframe', src=True):
            src = iframe.get('src').strip()
            if src and not src.startswith(('javascript:', 'about:', 'data:')):
                # Göreceli bağlantıları mutlak bağlantılara dönüştür
                if not src.startswith(('http://', 'https://')):
                    if src.startswith('//'):
                        src = 'https:' + src
                    elif src.startswith('/'):
                        # Üçlü slash oluşumunu önle
                        base_url = self.base_url.rstrip('/')
                        src = base_url + src
                    else:
                        src = urllib.parse.urljoin(current_url, src)
                
                # URL'yi normalize et
                normalized_url = self._normalize_url(src)
                
                # Geçerli URL'leri listeye ekle
                if self._is_valid_url(normalized_url):
                    links.add(normalized_url)
        
        # 4. Meta refresh etiketlerini kontrol et
        for meta in soup.find_all('meta', attrs={'http-equiv': lambda x: x and x.lower() == 'refresh'}):
            content = meta.get('content', '')
            if content and 'url=' in content.lower():
                refresh_url = content.split('url=')[1].strip()
                if refresh_url and not refresh_url.startswith(('javascript:', '#')):
                    # Göreceli bağlantıları mutlak bağlantılara dönüştür
                    if not refresh_url.startswith(('http://', 'https://')):
                        if refresh_url.startswith('//'):
                            refresh_url = 'https:' + refresh_url
                        elif refresh_url.startswith('/'):
                            # Üçlü slash oluşumunu önle
                            base_url = self.base_url.rstrip('/')
                            refresh_url = base_url + refresh_url
                        else:
                            refresh_url = urllib.parse.urljoin(current_url, refresh_url)
                    
                    # URL'yi normalize et
                    normalized_url = self._normalize_url(refresh_url)
                    
                    # Geçerli URL'leri listeye ekle
                    if self._is_valid_url(normalized_url):
                        links.add(normalized_url)
        
        # 5. Script içindeki URL kalıplarını ara (çok temel düzeyde)
        for script in soup.find_all('script'):
            if script.string:
                # URL kalıplarını basit regex ile çıkar
                url_patterns = [
                    r'["\'](https?://[^"\']+)["\']',
                    r'["\'](/[^"\']+)["\']'
                ]
                
                for pattern in url_patterns:
                    for match in re.finditer(pattern, script.string):
                        href = match.group(1)
                        
                        # Göreceli bağlantıları mutlak bağlantılara dönüştür
                        if href.startswith('/'):
                            # Üçlü slash oluşumunu önle
                            base_url = self.base_url.rstrip('/')
                            href = base_url + href
                        elif not href.startswith(('http://', 'https://')):
                            href = urllib.parse.urljoin(current_url, href)
                        
                        # URL'yi normalize et
                        normalized_url = self._normalize_url(href)
                        
                        # Geçerli URL'leri listeye ekle
                        if self._is_valid_url(normalized_url):
                            links.add(normalized_url)
        
        # 6. Keşfedici URL arama - "sitemap", "harita", "map" gibi anahtar kelimelerle
        explorer_paths = ['/sitemap', '/site-map', '/site-haritasi', '/site-map.html', '/sitemap.html']
        for path in explorer_paths:
            explorer_url = self.base_url.rstrip('/') + path
            normalized_url = self._normalize_url(explorer_url)
            if self._is_valid_url(normalized_url):
                links.add(normalized_url)
        
        # 7. Ana sayfadan türetilen yaygın URL'ler
        common_paths = ['/about', '/hakkimizda', '/iletisim', '/contact', '/products', '/urunler', '/blog']
        for path in common_paths:
            common_url = self.base_url.rstrip('/') + path
            normalized_url = self._normalize_url(common_url)
            if self._is_valid_url(normalized_url):
                links.add(normalized_url)
        
        # Link sayısını raporla
        print(f"URL'den çıkarılan bağlantı sayısı: {len(links)} - {current_url}")
        return list(links)
    
    def crawl(self):
        """Siteyi tarar ve URL'leri toplar."""
        logger.info(f"Tarama başlatılıyor: {self.start_url}")
        print(f"\n----- Tarama başlatılıyor: {self.start_url} -----\n")
        
        while self.urls_to_crawl and len(self.sitemap_urls) < self.max_urls:
            # Rastgele farklı bir kullanıcı aracısı seç
            self.headers['User-Agent'] = random.choice(self.user_agents)
            
            # URL'yi kuyruğun başından çıkar
            current_url = self.urls_to_crawl.pop(0)
            
            # URL varyantlarını kontrol et
            variants = self._get_url_variants(current_url)
            if any(variant in self.visited_urls for variant in variants):
                print(f"Zaten ziyaret edilmiş (varyant): {current_url}")
                continue
                
            if current_url in self.visited_urls:
                continue
                
            logger.info(f"Taranıyor: {current_url}")
            print(f"\n> Taranıyor: {current_url}")
            
            try:
                response = requests.get(current_url, headers=self.headers, timeout=10)
                
                # Başarılı yanıt kontrolü
                if response.status_code == 200:
                    # HTML içeriği kontrol et
                    content_type = response.headers.get('Content-Type', '')
                    if 'text/html' in content_type:
                        # URL'yi ziyaret edildi olarak işaretle
                        self.visited_urls.add(current_url)
                        self.sitemap_urls.append(current_url)
                        
                        # URL varyantlarını da ziyaret edilmiş olarak işaretle
                        for variant in variants:
                            self.visited_urls.add(variant)
                        
                        # Linkleri çıkar ve taranacaklar listesine ekle
                        links = self._extract_links(response.text, current_url)
                        print(f"Bulunan yeni linkler: {len(links)}")
                        
                        # Linkleri ilgili URL'ye göre sırala
                        sorted_links = sorted(links, key=lambda link: urllib.parse.urlparse(link).path.count('/'))
                        
                        for link in sorted_links:
                            # Ziyaret edilmemiş ve kuyruğa eklenmemiş URL'leri ekle
                            link_variants = self._get_url_variants(link)
                            if not any(variant in self.visited_urls for variant in link_variants) and link not in self.urls_to_crawl:
                                self.urls_to_crawl.append(link)
                        
                        print(f"✓ Ziyaret edilen URL sayısı: {len(self.visited_urls)}")
                        print(f"✓ Taranacak URL kuyruğu: {len(self.urls_to_crawl)}")
                    else:
                        print(f"✗ HTML olmayan içerik atlandı: {current_url} - Tür: {content_type}")
                        logger.debug(f"HTML olmayan içerik atlandı: {current_url}")
                else:
                    print(f"✗ HTTP {response.status_code}: {current_url}")
                    logger.warning(f"HTTP {response.status_code}: {current_url}")
            
            except Exception as e:
                print(f"✗ Tarama hatası ({current_url}): {e}")
                logger.error(f"Tarama hatası ({current_url}): {e}")
            
            # Tarama gecikmesi - web sitesini aşırı yüklememek için
            jitter = random.uniform(-0.2, 0.2) * self.crawl_delay  # %20 rastgele değişim
            delay = max(0.1, self.crawl_delay + jitter)  # Minimum 0.1 saniye
            time.sleep(delay)
            
            # İlerleme bilgisi göster
            if len(self.sitemap_urls) % 5 == 0 and len(self.sitemap_urls) > 0:
                print(f"\n--- İlerleme: {len(self.sitemap_urls)}/{self.max_urls} URL bulundu ---")
        
        # Özet bilgileri göster
        print("\n" + "="*50)
        print(f"TARAMA TAMAMLANDI - {len(self.sitemap_urls)} URL BULUNDU")
        print("="*50)
        
        if self.sitemap_urls:
            print("\nBulunan URL'ler:")
            for i, url in enumerate(self.sitemap_urls[:10], 1):  # İlk 10 URL'yi göster
                print(f"{i}. {url}")
            
            if len(self.sitemap_urls) > 10:
                print(f"... ve {len(self.sitemap_urls) - 10} URL daha")
        
        if len(self.external_urls) > 0:
            print(f"\n{len(self.external_urls)} harici URL atlandı (örnekler):")
            for url in self.external_urls[:5]:  # Sadece ilk 5 örneği göster
                print(f"- {url}")
        
        if len(self.skipped_urls) > 0:
            print(f"\n{len(self.skipped_urls)} geçersiz URL atlandı (örnekler):")
            for reason in self.skipped_urls[:5]:  # Sadece ilk 5 örneği göster
                print(f"- {reason}")
        
        logger.info(f"Tarama tamamlandı. {len(self.sitemap_urls)} URL toplandı.")
        print(f"\nTarama tamamlandı. {len(self.sitemap_urls)} URL toplandı.")
    
    def generate_sitemap(self):
        """Toplanan URL'lerden sitemap.xml dosyası oluşturur."""
        logger.info("Sitemap oluşturuluyor...")
        
        # Eğer URL bulunamadıysa, örnek bir URL ekleyelim
        if not self.sitemap_urls and self.start_url:
            self.sitemap_urls.append(self.start_url)
            print("Hiç URL bulunamadı. Ana URL ekleniyor.")
        
        # URLSet elementini oluştur
        urlset = ET.Element("urlset")
        urlset.set("xmlns", "http://www.sitemaps.org/schemas/sitemap/0.9")
        
        # Bugünün tarihini al
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        
        # Her URL için bir URL elementi ekle
        for url in self.sitemap_urls:
            url_element = ET.SubElement(urlset, "url")
            
            # Zorunlu loc elementini ekle
            loc = ET.SubElement(url_element, "loc")
            loc.text = url
            
            # İsteğe bağlı lastmod elementini ekle
            lastmod = ET.SubElement(url_element, "lastmod")
            lastmod.text = today
            
            # İsteğe bağlı changefreq elementini ekle
            changefreq = ET.SubElement(url_element, "changefreq")
            
            # Ana sayfaya daha yüksek öncelik ver
            if url == self.start_url or url == self.base_url or url == self.base_url + '/':
                changefreq.text = "weekly"
            else:
                # URL derinliğine göre değişiklik sıklığını belirle
                depth = url.count('/') - self.base_url.count('/')
                if depth <= 1:
                    changefreq.text = "monthly"
                elif depth == 2:
                    changefreq.text = "weekly"
                else:
                    changefreq.text = "monthly"
            
            # İsteğe bağlı priority elementini ekle
            priority = ET.SubElement(url_element, "priority")
            
            # Ana sayfaya daha yüksek öncelik ver
            if url == self.start_url or url == self.base_url or url == self.base_url + '/':
                priority.text = "1.0"
            else:
                # URL derinliğine göre öncelik belirle
                depth = url.count('/') - self.base_url.count('/')
                if depth <= 1:
                    priority.text = "0.8"
                elif depth == 2:
                    priority.text = "0.6"
                else:
                    priority.text = "0.4"
        
        # XML'i güzel formatlı şekilde diske yaz
        xml_str = minidom.parseString(ET.tostring(urlset)).toprettyxml(indent="  ")
        
        # XML başlığını düzelt (minidom bazen fazladan satır ekleyebiliyor)
        xml_str = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_str.split('?>', 1)[1]
        
        with open(self.output_file, "w", encoding="utf-8") as f:
            f.write(xml_str)
        
        logger.info(f"Sitemap oluşturuldu: {self.output_file}")
        print(f"Sitemap oluşturuldu: {self.output_file}")
    
    def run(self):
        """Tarama ve sitemap oluşturma işlemini çalıştırır."""
        self.crawl()
        self.generate_sitemap()
        return self.output_file

def main():
    # Komut satırı argümanlarını tanımla
    parser = argparse.ArgumentParser(description="Sitemap Oluşturucu")
    parser.add_argument("url", help="Taramaya başlanacak URL")
    parser.add_argument("-o", "--output", default="sitemap.xml", help="Çıktı dosyasının adı")
    parser.add_argument("-m", "--max", type=int, default=500, help="Taranacak maksimum URL sayısı")
    parser.add_argument("-d", "--delay", type=float, default=0.5, help="Tarama gecikmesi (saniye)")
    parser.add_argument("--no-robots", action="store_true", help="robots.txt'yi görmezden gel")
    parser.add_argument("-e", "--exclude", nargs="*", default=[], help="Hariç tutulacak URL kalıpları")
    parser.add_argument("-v", "--verbose", action="store_true", help="Detaylı log bilgisi göster")
    
    args = parser.parse_args()
    
    # Detaylı log için log seviyesini ayarla
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Sitemap oluşturucuyu başlat
    generator = SitemapGenerator(
        args.url,
        output_file=args.output,
        max_urls=args.max,
        crawl_delay=args.delay,
        respect_robots=not args.no_robots,
        excluded_patterns=args.exclude
    )
    
    print(f"Sitemap oluşturma başlatılıyor: {args.url}")
    print(f"Maksimum URL sayısı: {args.max}")
    
    start_time = time.time()
    output_file = generator.run()
    end_time = time.time()
    
    elapsed_time = end_time - start_time
    print(f"Sitemap başarıyla oluşturuldu: {output_file}")
    print(f"İşlem süresi: {elapsed_time:.2f} saniye")
    print(f"Toplam URL sayısı: {len(generator.sitemap_urls)}")

if __name__ == "__main__":
    main() 