#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext, messagebox
import time
from datetime import datetime
import queue
import io
import contextlib
import requests
from ttkthemes import ThemedTk

from sitemap_generator import SitemapGenerator

class RedirectText:
    """Standart çıktıyı yakalamak için kullanılan sınıf"""
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.buffer = queue.Queue()
        self.daemon = True
        
    def write(self, string):
        self.buffer.put(string)
        
    def flush(self):
        pass
        
    def update_widget(self):
        """Text widget'ını günceller"""
        try:
            while True:
                text = self.buffer.get_nowait()
                self.text_widget.configure(state='normal')
                self.text_widget.insert('end', text)
                self.text_widget.see('end')
                self.text_widget.configure(state='disabled')
                self.buffer.task_done()
        except queue.Empty:
            pass
        finally:
            self.text_widget.after(100, self.update_widget)

class SitemapGeneratorUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Sitemap Oluşturucu")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)
        
        self.setup_style()
        self.create_variables()
        self.create_ui_components()
        self.arrange_layout()
        self.crawling_thread = None
        self.setup_stdout_redirect()
        
    def setup_style(self):
        """UI stilini ayarlar"""
        style = ttk.Style()
        style.configure("TFrame", background="#f5f5f5")
        style.configure("TLabel", background="#f5f5f5", font=("Arial", 10))
        style.configure("TButton", font=("Arial", 10))
        style.configure("Header.TLabel", font=("Arial", 12, "bold"))
        style.configure("Title.TLabel", font=("Arial", 16, "bold"))
        style.configure("Status.TLabel", font=("Arial", 10, "italic"))
        
        # Progress bar stili
        style.configure("TProgressbar", thickness=20)
        
    def create_variables(self):
        """Tkinter değişkenlerini oluşturur"""
        self.url_var = tk.StringVar(value="")
        self.output_file_var = tk.StringVar(value="sitemap.xml")
        self.max_urls_var = tk.IntVar(value=500)
        self.delay_var = tk.DoubleVar(value=0.5)
        self.respect_robots_var = tk.BooleanVar(value=True)
        self.excluded_patterns_var = tk.StringVar(value="")
        self.progress_var = tk.DoubleVar(value=0.0)
        self.status_var = tk.StringVar(value="Hazır")
        self.crawling = False
        
    def create_ui_components(self):
        """UI bileşenlerini oluşturur"""
        # Ana bileşenleri oluştur
        self.main_frame = ttk.Frame(self.root, padding="10")
        
        # Başlık
        self.title_frame = ttk.Frame(self.main_frame)
        self.title_label = ttk.Label(self.title_frame, text="Sitemap Oluşturucu", style="Title.TLabel")
        
        # URL giriş alanı
        self.url_frame = ttk.Frame(self.main_frame, padding=(0, 10))
        self.url_label = ttk.Label(self.url_frame, text="Web Sitesi URL:", style="Header.TLabel")
        self.url_entry = ttk.Entry(self.url_frame, textvariable=self.url_var, width=50)
        self.start_button = ttk.Button(self.url_frame, text="Taramayı Başlat", command=self.start_crawling)
        self.stop_button = ttk.Button(self.url_frame, text="Durdur", command=self.stop_crawling, state="disabled")
        
        # Ayarlar çerçevesi
        self.settings_frame = ttk.LabelFrame(self.main_frame, text="Ayarlar", padding="10")
        
        # Çıktı dosyası
        self.output_frame = ttk.Frame(self.settings_frame)
        self.output_label = ttk.Label(self.output_frame, text="Çıktı Dosyası:")
        self.output_entry = ttk.Entry(self.output_frame, textvariable=self.output_file_var, width=30)
        self.browse_button = ttk.Button(self.output_frame, text="Gözat...", command=self.browse_output_file)
        
        # Maksimum URL sayısı
        self.max_urls_frame = ttk.Frame(self.settings_frame)
        self.max_urls_label = ttk.Label(self.max_urls_frame, text="Maksimum URL Sayısı:")
        self.max_urls_spinbox = ttk.Spinbox(self.max_urls_frame, from_=1, to=10000, textvariable=self.max_urls_var, width=10)
        
        # Tarama gecikmesi
        self.delay_frame = ttk.Frame(self.settings_frame)
        self.delay_label = ttk.Label(self.delay_frame, text="Tarama Gecikmesi (saniye):")
        self.delay_spinbox = ttk.Spinbox(self.delay_frame, from_=0.1, to=10.0, increment=0.1, textvariable=self.delay_var, width=10)
        
        # Robots.txt seçeneği
        self.robots_frame = ttk.Frame(self.settings_frame)
        self.robots_check = ttk.Checkbutton(self.robots_frame, text="Robots.txt kurallarına uy", variable=self.respect_robots_var)
        
        # Hariç tutulacak kalıplar
        self.exclude_frame = ttk.Frame(self.settings_frame)
        self.exclude_label = ttk.Label(self.exclude_frame, text="Hariç Tutulacak Kalıplar (virgülle ayrılmış):")
        self.exclude_entry = ttk.Entry(self.exclude_frame, textvariable=self.excluded_patterns_var, width=40)
        
        # İlerleme çubuğu
        self.progress_frame = ttk.Frame(self.main_frame, padding=(0, 10))
        self.progress_bar = ttk.Progressbar(self.progress_frame, orient="horizontal", length=600, mode="determinate", variable=self.progress_var)
        self.status_label = ttk.Label(self.progress_frame, textvariable=self.status_var, style="Status.TLabel")
        
        # Sekme kontrol
        self.tab_control = ttk.Notebook(self.main_frame)
        
        # Log sekmesi
        self.log_frame = ttk.Frame(self.tab_control, padding="10")
        self.log_text = scrolledtext.ScrolledText(self.log_frame, wrap=tk.WORD, width=80, height=15)
        self.log_text.configure(state='disabled')
        
        # Önizleme sekmesi
        self.preview_frame = ttk.Frame(self.tab_control, padding="10")
        self.preview_text = scrolledtext.ScrolledText(self.preview_frame, wrap=tk.WORD, width=80, height=15)
        self.preview_text.configure(state='disabled')
        
        # Sekmeleri ekle
        self.tab_control.add(self.log_frame, text="Log Çıktısı")
        self.tab_control.add(self.preview_frame, text="Sitemap Önizleme")
        
    def arrange_layout(self):
        """UI bileşenlerini yerleştirir"""
        # Ana çerçeveyi yerleştir
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Başlık
        self.title_frame.pack(fill=tk.X, pady=(0, 10))
        self.title_label.pack()
        
        # URL giriş alanı
        self.url_frame.pack(fill=tk.X)
        self.url_label.pack(side=tk.LEFT, padx=(0, 10))
        self.url_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.stop_button.pack(side=tk.RIGHT, padx=(5, 0))
        self.start_button.pack(side=tk.RIGHT)
        
        # Ayarlar çerçevesi
        self.settings_frame.pack(fill=tk.X, pady=10)
        
        # Çıktı dosyası
        self.output_frame.pack(fill=tk.X, pady=5)
        self.output_label.pack(side=tk.LEFT, padx=(0, 10))
        self.output_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.browse_button.pack(side=tk.LEFT, padx=(5, 0))
        
        # Maksimum URL sayısı
        self.max_urls_frame.pack(fill=tk.X, pady=5)
        self.max_urls_label.pack(side=tk.LEFT, padx=(0, 10))
        self.max_urls_spinbox.pack(side=tk.LEFT)
        
        # Tarama gecikmesi
        self.delay_frame.pack(fill=tk.X, pady=5)
        self.delay_label.pack(side=tk.LEFT, padx=(0, 10))
        self.delay_spinbox.pack(side=tk.LEFT)
        
        # Robots.txt seçeneği
        self.robots_frame.pack(fill=tk.X, pady=5)
        self.robots_check.pack(side=tk.LEFT)
        
        # Hariç tutulacak kalıplar
        self.exclude_frame.pack(fill=tk.X, pady=5)
        self.exclude_label.pack(side=tk.LEFT, padx=(0, 10))
        self.exclude_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # İlerleme çubuğu
        self.progress_frame.pack(fill=tk.X)
        self.progress_bar.pack(side=tk.TOP, fill=tk.X)
        self.status_label.pack(side=tk.LEFT, padx=(0, 10), pady=(5, 0))
        
        # Sekme kontrol
        self.tab_control.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Log metin alanı
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Önizleme metin alanı
        self.preview_text.pack(fill=tk.BOTH, expand=True)
        
    def setup_stdout_redirect(self):
        """Standart çıktıyı yakalamak için yönlendirme kurulumu"""
        self.stdout_redirect = RedirectText(self.log_text)
        self.stdout_redirect.update_widget()
        
    def browse_output_file(self):
        """Çıktı dosyası için dosya tarayıcısını açar"""
        filename = filedialog.asksaveasfilename(
            defaultextension=".xml",
            filetypes=[("XML dosyaları", "*.xml"), ("Tüm dosyalar", "*.*")],
            initialfile=self.output_file_var.get()
        )
        if filename:
            self.output_file_var.set(filename)
    
    def update_progress(self, current_urls, max_urls):
        """İlerleme çubuğunu günceller"""
        progress = min(100, int((current_urls / max_urls) * 100))
        self.progress_var.set(progress)
        self.status_var.set(f"İlerleme: {current_urls}/{max_urls} URL tarandı ({progress}%)")
    
    def update_preview(self, sitemap_content):
        """Sitemap önizleme sekmesini günceller"""
        self.preview_text.configure(state='normal')
        self.preview_text.delete(1.0, tk.END)
        self.preview_text.insert(tk.END, sitemap_content)
        self.preview_text.configure(state='disabled')
        
    def start_crawling(self):
        """Tarama işlemini başlatır"""
        if self.crawling:
            return
            
        url = self.url_var.get().strip()
        if not url:
            messagebox.showerror("Hata", "Lütfen bir URL girin.")
            return
            
        # UI bileşenlerini güncelle
        self.crawling = True
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.progress_var.set(0)
        self.status_var.set("Tarama başlatılıyor...")
        
        # Log alanını temizle
        self.log_text.configure(state='normal')
        self.log_text.delete(1.0, tk.END)
        self.log_text.configure(state='disabled')
        
        # Önizleme alanını temizle
        self.preview_text.configure(state='normal')
        self.preview_text.delete(1.0, tk.END)
        self.preview_text.configure(state='disabled')
        
        # Parametreleri al
        output_file = self.output_file_var.get()
        max_urls = self.max_urls_var.get()
        delay = self.delay_var.get()
        respect_robots = self.respect_robots_var.get()
        
        # Hariç tutulan kalıpları ayır
        excluded_patterns = []
        if self.excluded_patterns_var.get():
            excluded_patterns = [p.strip() for p in self.excluded_patterns_var.get().split(",")]
        
        # Tarama işlemi için yeni bir thread başlat
        self.crawling_thread = threading.Thread(
            target=self._crawl_thread,
            args=(url, output_file, max_urls, delay, respect_robots, excluded_patterns),
            daemon=True
        )
        self.crawling_thread.start()
    
    def _crawl_thread(self, url, output_file, max_urls, delay, respect_robots, excluded_patterns):
        """Arka planda tarama işlemi için thread fonksiyonu"""
        try:
            # Çıktıyı yakala
            old_stdout = sys.stdout
            sys.stdout = self.stdout_redirect
            
            print(f"Tarama başlatılıyor: {url}")
            print(f"Maksimum URL sayısı: {max_urls}")
            print(f"Tarama gecikmesi: {delay} saniye")
            print(f"Robots.txt kurallarına uy: {'Evet' if respect_robots else 'Hayır'}")
            if excluded_patterns:
                print(f"Hariç tutulan kalıplar: {', '.join(excluded_patterns)}")
            print("-" * 50)
            
            # SitemapGenerator oluştur
            generator = SitemapGenerator(
                url,
                output_file=output_file,
                max_urls=max_urls,
                crawl_delay=delay,
                respect_robots=respect_robots,
                excluded_patterns=excluded_patterns
            )
            
            # UI için ilerlemesini takip eden özel bir fonksiyon tanımlayalım
            def progress_tracker():
                """Tarama sırasında ilerlemeyi izler"""
                last_count = 0
                while self.crawling and len(generator.sitemap_urls) < generator.max_urls:
                    current_count = len(generator.sitemap_urls)
                    if current_count != last_count:
                        self.root.after(0, self.update_progress, current_count, generator.max_urls)
                        last_count = current_count
                    time.sleep(0.5)
            
            # İlerleme izleyicisini başlat
            progress_thread = threading.Thread(target=progress_tracker, daemon=True)
            progress_thread.start()
            
            # Tarama işlemini başlat
            start_time = time.time()
            
            # Orijinal crawl metodunu kullan, kendi metodumuzu yazmak yerine
            generator.crawl()  
            
            if not self.crawling:
                print("\nTarama işlemi kullanıcı tarafından durduruldu.")
                self.root.after(0, lambda: self.status_var.set("Tarama durduruldu"))
                return
                
            # Sitemap oluştur
            generator.generate_sitemap()
            
            # İlerlemeyi tamamlanmış olarak işaretle
            self.root.after(0, self.update_progress, len(generator.sitemap_urls), max_urls)
            
            # Sitemap içeriğini oku ve önizleme sekmesinde göster
            with open(output_file, 'r', encoding='utf-8') as f:
                sitemap_content = f.read()
                self.root.after(0, self.update_preview, sitemap_content)
            
            # İşlem bilgisini göster
            end_time = time.time()
            elapsed_time = end_time - start_time
            print("\nTarama işlemi tamamlandı!")
            print(f"İşlem süresi: {elapsed_time:.2f} saniye")
            print(f"Toplam URL sayısı: {len(generator.sitemap_urls)}")
            print(f"Sitemap oluşturuldu: {output_file}")
            
            # UI durumunu güncelle
            self.root.after(0, lambda: self.status_var.set(f"Tamamlandı: {len(generator.sitemap_urls)} URL tarandı"))
            
        except Exception as e:
            print(f"Tarama sırasında bir hata oluştu: {e}")
            import traceback
            traceback.print_exc()
            self.root.after(0, lambda: self.status_var.set("Hata oluştu"))
            
        finally:
            # Standart çıktıyı geri yükle
            sys.stdout = old_stdout
            
            # UI bileşenlerini güncelle
            self.root.after(0, self._reset_ui_after_crawling)
    
    def _reset_ui_after_crawling(self):
        """Tarama işlemi sonrasında UI'yı sıfırlar"""
        self.crawling = False
        self.start_button.configure(state="normal")
        self.stop_button.configure(state="disabled")
    
    def stop_crawling(self):
        """Tarama işlemini durdurur"""
        if self.crawling:
            self.crawling = False
            self.status_var.set("Tarama durduruluyor...")
    
def main():
    root = ThemedTk(theme="arc")  # Modern bir tema kullan
    app = SitemapGeneratorUI(root)
    root.mainloop()

if __name__ == "__main__":
    main() 